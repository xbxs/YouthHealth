package com.example.youthhealth.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;


import com.example.youthhealth.R;
import com.example.youthhealth.VideoListViewAdapter;
import com.example.youthhealth.entity.Video;

import java.util.ArrayList;
import java.util.List;

import cn.jzvd.JZVideoPlayer;


public class VideoFragment extends Fragment {



    private ListView list_video;

    private List<Video> mVideoList;

//    private

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_ask, container, false);
        list_video = view.findViewById(R.id.list_video);

       // player.thumbImageView();
        initData();

        list_video.setAdapter(new VideoListViewAdapter(getContext(),mVideoList));
        return view;
    }

    private void initData() {
        mVideoList = new ArrayList<>();
        mVideoList.add(new Video("第一个视频","http://gslb.miaopai.com/stream/ed5HCfnhovu3tyIQAiv60Q__.mp4","http://a4.att.hudong.com/05/71/01300000057455120185716259013.jpg"));
        mVideoList.add(new Video("第二个视频","http://gslb.miaopai.com/stream/ed5HCfnhovu3tyIQAiv60Q__.mp4","http://a4.att.hudong.com/05/71/01300000057455120185716259013.jpg"));
        mVideoList.add(new Video("第三个视频","http://gslb.miaopai.com/stream/ed5HCfnhovu3tyIQAiv60Q__.mp4","http://a4.att.hudong.com/05/71/01300000057455120185716259013.jpg"));
        mVideoList.add(new Video("第四个视频","http://gslb.miaopai.com/stream/ed5HCfnhovu3tyIQAiv60Q__.mp4","http://a4.att.hudong.com/05/71/01300000057455120185716259013.jpg"));
        mVideoList.add(new Video("第五个视频","http://gslb.miaopai.com/stream/ed5HCfnhovu3tyIQAiv60Q__.mp4","http://a4.att.hudong.com/05/71/01300000057455120185716259013.jpg"));

    }



    @Override
    public void onPause() {
        super.onPause();
        JZVideoPlayer.releaseAllVideos();
    }

}
