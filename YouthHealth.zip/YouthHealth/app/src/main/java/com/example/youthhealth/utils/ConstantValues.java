package com.example.youthhealth.utils;

/**
 * 李维: TZZ on 2019-11-23 14:29
 * 邮箱: 3182430026@qq.com
 */
public class ConstantValues {
    //sp存储文件的名称
    public static final String CONFIG = "config";

    //判断是否为第一次打开app
    public static  final String IS_FIRSTOPEN = "is_firstopen";
}
