package com.example.youthhealth.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.example.youthhealth.R;
import com.example.youthhealth.entity.Food;

import java.util.ArrayList;
import java.util.List;

/**
 *   这个碎片主要是呈现出主页健康饮食
 */

public class FoodFragment extends Fragment {
    private  ViewPager vp_food_guide;
    private View mView;
    private ListView lv_dynamic;
    private int[] images = new int[]{R.drawable.food1,R.drawable.food2,R.drawable.food3,R.drawable.food4};
    //轮播的图
    private List<ImageView> mImageViewList;
//    动态数据
    private List<Food> mFoodList;
//    小圆点的容器
    private LinearLayout ll_food_carousel;
    private int beforepoint = 0;
    private boolean isRunning = false;
    //自动轮播
    private myHandler mMyHandler = new myHandler();
//    按顺序 oncreate在oncreateView之前
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mView = inflater.inflate(R.layout.fragment_food, container, false);
        vp_food_guide = mView.findViewById(R.id.vp_food_guide);
        ll_food_carousel = mView.findViewById(R.id.ll_food_carousel);
        lv_dynamic = mView.findViewById(R.id.lv_dynamic);

        initDate();
        lv_dynamic.setAdapter(new MyListAdapter());
        vp_food_guide.setAdapter(new FoodCarouselAdapter());
        vp_food_guide.setCurrentItem(5000000);

        vp_food_guide.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return false;
            }
        });
        vp_food_guide.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
               int newPosition = i % mImageViewList.size();
               ll_food_carousel.getChildAt(beforepoint).setEnabled(false);
               ll_food_carousel.getChildAt(newPosition).setEnabled(true);
               beforepoint = newPosition;

            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });


        //开启线程轮播
        new Thread(new Runnable() {
            @Override
            public void run() {
                isRunning = true;
                while (isRunning){
                    SystemClock.sleep(2000);
                    mMyHandler.sendEmptyMessage(1);
                }
            }
        }).start();


        return mView;
    }

    private void initDate() {
        mImageViewList = new ArrayList<>();
        ImageView point;
        LinearLayout.LayoutParams layoutParams;
        for(int i = 0;i < images.length; i++){
            ImageView imageView = new ImageView(getContext());
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            imageView.setImageResource(images[i]);
            mImageViewList.add(imageView);

            point = new ImageView(getContext());
            point.setBackgroundResource(R.drawable.selector_food_carousel);
            layoutParams = new LinearLayout.LayoutParams(35,35);
            if(i != 0){
                layoutParams.leftMargin = 15;
                point.setEnabled(false);
            }


            ll_food_carousel.addView(point,layoutParams);
        }
        //初始化动态数据
        mFoodList = new ArrayList<>();
        int[] mimages = new int[]{R.drawable.food_list_2,R.drawable.food_list_3,R.drawable.food_list_4};
        String[] titles = new String[]{"燕麦和麦片有什么区别","食疗养生食谱-天麻鱼头汤","食疗养生食谱-枸杞猪肝汤"};
        String[] types = new String[]{"养生 秋冬","教程","养生"};
        String[] extendUri = new String[]{"1","2","3"};

        for(int i = 0;i < mimages.length;i++) {

            mFoodList.add(new Food(mimages[i],titles[i],types[i],extendUri[i]));
            mFoodList.add(new Food(mimages[i],titles[i],types[i],extendUri[i]));
        }
    }
    // 轮播适配器
    class FoodCarouselAdapter extends PagerAdapter{

        @Override
        public int getCount() {
            return Integer.MAX_VALUE;
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
            return view == o;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            ImageView imageView = mImageViewList.get(position%mImageViewList.size());
            container.addView(imageView);
            return imageView;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            container.removeView((View) object);
        }
    }

    class myHandler extends Handler{

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            vp_food_guide.setCurrentItem(vp_food_guide.getCurrentItem() + 1);
        }
    }
    //listview的适配器
    class  MyListAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return mFoodList.size();
        }

        @Override
        public Object getItem(int i) {
            return mFoodList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }
        //得到item视图
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            ViewHolder holder;
            if(view == null){
                view = View.inflate(getContext(),R.layout.layout_food_dynamic,null);

                holder = new ViewHolder();
                holder.layout_picture = view.findViewById(R.id.layout_picture);
                holder.layout_title = view.findViewById(R.id.layout_title);
                holder.layout_type = view.findViewById(R.id.layout_type);
                view.setTag(holder);
            }else{
                holder = (ViewHolder) view.getTag();
            }
            //得到数据得javabean
            Food food = mFoodList.get(i);
            holder.layout_picture.setImageResource(food.getUri());
            holder.layout_title.setText(food.getTitle());
            String[] arry = food.getMtype().split("\\s");
            LinearLayout.LayoutParams params;

            holder.layout_type.removeAllViews();
            for(int j= 0; j < arry.length;j++) {

                params = new LinearLayout.LayoutParams(120,80);
                params.leftMargin = 50;
                TextView textView = new TextView(getContext());
                textView.setGravity(Gravity.CENTER);
                textView.setBackgroundResource(R.drawable.food_list_type_bg);
                textView.setText(arry[j]);

                holder.layout_type.addView(textView,params);
            }
            return view;
        }


    }

    static class ViewHolder{
        ImageView layout_picture;
        TextView layout_title;
        LinearLayout layout_type;
    }




    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
    }
}
