package com.example.youthhealth.entity;

/**
 * 李维: TZZ on 2019-11-25 18:43
 * 邮箱: 3182430026@qq.com
 */
public class Food {
    private int  uri;
    private String title;
    private String mtype;
    private String extendUri;

    public Food(int uri, String title, String mtype, String extendUri) {
        this.uri = uri;
        this.title = title;
        this.mtype = mtype;
        this.extendUri = extendUri;
    }

    public Food() {
    }

    public int getUri() {
        return uri;
    }

    public void setUri(int uri) {
        this.uri = uri;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMtype() {
        return mtype;
    }

    public void setMtype(String mtype) {
        this.mtype = mtype;
    }

    public String getExtendUri() {
        return extendUri;
    }

    public void setExtendUri(String extendUri) {
        this.extendUri = extendUri;
    }
}
