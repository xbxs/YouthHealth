package com.example.youthhealth;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.bumptech.glide.Glide;
import com.example.youthhealth.entity.Video;

import java.util.List;

import cn.jzvd.JZVideoPlayerStandard;

/**
 * 李维: TZZ on 2019-11-29 21:01
 * 邮箱: 3182430026@qq.com
 */
public class VideoListViewAdapter extends BaseAdapter {
    private List<Video> mVideos;
    private Context mContext;
    public VideoListViewAdapter(Context context,List<Video> lists){
        this.mVideos = lists;
        this.mContext = context;
    }
    @Override
    public int getCount() {
        return mVideos.size();
    }

    @Override
    public Object getItem(int i) {
        return mVideos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if(view == null){
            view = View.inflate(mContext,R.layout.item_video,null);
            holder = new ViewHolder();
            holder.mJzvdStd = view.findViewById(R.id.player_lsit_video);
            view.setTag(holder);
        }else{
            holder = (ViewHolder) view.getTag();
        }
        Video video = mVideos.get(i);
        holder.mJzvdStd.setUp(video.getVideoUri(),JZVideoPlayerStandard.SCREEN_WINDOW_NORMAL,video.getTitle());

        Glide.with(mContext).load(video.getVideoFirstPicture()).into(holder.mJzvdStd.thumbImageView);

        return view;
    }

    static class ViewHolder{
        JZVideoPlayerStandard mJzvdStd;

    }
}
