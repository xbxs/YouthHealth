package com.example.youthhealth;

import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;

import com.example.youthhealth.utils.ConstantValues;
import com.example.youthhealth.utils.PrefUtils;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Thread(new Runnable() {
            @Override
            public void run() {
                SystemClock.sleep(2000);

                boolean is_FirstOpen = PrefUtils.getBoolean(SplashActivity.this, ConstantValues.IS_FIRSTOPEN,true);
                Intent intent = null;
                if(is_FirstOpen){
                    intent = new Intent(SplashActivity.this, GuideActivity.class);
                }else{
                    intent = new Intent(SplashActivity.this, MainActivity.class);
                }

                startActivity(intent);
                finish();
            }
        }).start();


    }
}
