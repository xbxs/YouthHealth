package com.example.youthhealth.entity;

/**
 * 李维: TZZ on 2019-11-29 21:03
 * 邮箱: 3182430026@qq.com
 */
public class Video {
    private String title;
    private String videoUri;

    private String videoFirstPicture;


    public Video() {
    }

    public Video(String title, String videoUri, String videoFirstPicture) {
        this.title = title;
        this.videoUri = videoUri;
        this.videoFirstPicture = videoFirstPicture;
    }

    public String getVideoUri() {
        return videoUri;
    }

    public void setVideoUri(String videoUri) {
        this.videoUri = videoUri;
    }

    public String getVideoFirstPicture() {
        return videoFirstPicture;
    }

    public void setVideoFirstPicture(String videoFirstPicture) {
        this.videoFirstPicture = videoFirstPicture;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
